type litteral = 
  |P of int 
  |N of int

type clause = litteral * litteral;;
type twocnf = clause list;;
type valuation = bool array;;

let rec eval_litt litt v = 
  match litt with 
  |N(n) -> not v.(n)
  |P(n) -> v.(n)


let rec eval f v = 
  match f with 
  |[] -> true
  |(a,b):: reste -> 
    (eval_litt a v || eval_litt b v) && eval reste v ;;


exception Last 
let increment_valuation v = 
  let rec loop i = 
    if i < 0 then raise Last (*on dépasse*)
    else if not v.(i) then v.(i) <- true (*on change de bit*)
    else 
    begin 
      v.(i) <- false;
      loop (i - 1)
    end
  in 
  loop (Array.length v - 1);;

let absolute litt = 
  match litt with 
  |N(i) | P(i) -> i

let rec max_var f = 
  match f with 
  |[] -> -1
  |(a,b) :: f' -> max (max_var f') (max (absolute a) (absolute b))

let brute_force f = 
  let maxi_var = max_var f in
  let v = Array.make maxi_var false in 
  try 
    while not (eval f v) do 
    increment_valuation v;
    done;
    Some v
  with
  |Last -> None