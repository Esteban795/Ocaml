let u0 = 42;;
let m = (1 lsl 31) - 1;;

type transition = {
  q' : int;
  y : int;
  d : int
}

type machine = {
  n : int;
  t: int;
  transitions : transition array array
}


type configuration = {
  bande : int array;
  p : int;
  q : int
}

let calc n modulo = 
  let temp = ref u0 in
  for i = 1 to n do 
    temp := (16807 * !temp) mod m
  done;
  !temp mod modulo;;

let print_machine m = 
  for q = 0 to m.n - 1 do
    for i = 0 to 1 do
      let t = m.transitions.(q).(i) in
      Printf.printf "Etat %d, x = %d, (%d,%d,%d)" q i t.q' t.y t.d;
      print_newline ()
    done;
  done;;


let generer_transition n t q x = 
  let z = t + 8 * q + 4 * x in 
  let g_d = 2 * (2 * (calc (z + 3) 2)) - 1 in 
  let y = calc (z + 2) 2 in
  let q' = if (calc (z + 1) n) = 0 then -1 else calc z n in 
  {q'=q';y=y;d=g_d};;

let generer_machine n t = 
  let mat = Array.make n (Array.make 2 {q'=0;y=0;d=0}) in
  for q = 0 to n - 1 do
    for x = 0 to 1 do 
      mat.(q).(x) <- generer_transition n t q x
    done;
  done;
  {n = n; t = t; transitions = mat};;


let compteur_t n k = 
  let compteur = ref 0 in 
  for t = 0 to 999 do 
    let m_t = generer_machine n t in 
    for q = 0 to n do 
      for i = 0 to 1 do 
        if m_t.transitions.(q).(i).y = (-1) then incr compteur;
      done;
    done;
  done;
  !compteur;;


let empty_band () = 
  {bande = Array.make 1001 0;p = 500; q = 0}


let opt c m_t = 
  let tr = m_t.transitions.(c.q).(c.bande.(c.p)) in 
  c.bande.(c.q) <- tr.q';
  c.bande.(c.p) <- c.p + tr.d;
  c.bande.(c.p) <- 500 + tr.y;


