module PrioQ :
sig
  type t
  val get_min : t -> (int * float)
  val extract_min : t -> (int * float)
  val insert : t -> (int * float) -> unit
  val length : t -> int
  val capacity : t -> int
  val make_empty : int -> t
  val decrease_priority : t -> (int * float) -> unit
  val mem : t -> int -> bool
end = struct

  type t =
    {mutable last : int;
     priorities : float array;
     keys : int array;
     mapping : int array}

  let length q = q.last + 1

  let capacity q = Array.length q.keys

  let make_empty n =
    {last = -1;
     priorities = Array.make n nan;
     keys = Array.make n 0;
     mapping = Array.make n (-1)}

  let mem q x =
    q.mapping.(x) >= 0

  let swap t i j =
    let tmp = t.(i) in
    t.(i) <- t.(j);
    t.(j) <- tmp

  let full_swap q i j = assert false

  let get_min q = (q.keys.(0), q.priorities.(0))

  let rec sift_up q i = assert false


  let insert q (x, prio) = assert false

  let rec sift_down q i = assert false

  let extract_min q = assert false

  let decrease_priority q (x, prio) = assert false
end


type weighted_graph = (int * float) list array

let g0 : weighted_graph =
  [| [(1, 15.); (2, 16.); (3, 13.); (4, 9.)];
     [(0, 15.); (4, 7.); (5, 1.)];
     [(0, 16.); (3, 5.); (4, 5.); (5, 6.)];
     [(0, 13.); (2, 5.); (4, 3.)];
     [(0, 9.); (1, 7.); (2, 5.); (3, 3.)];
     [(1, 1.); (2, 6.)] |]

let random_graph n avg_outdegree =
  Random.init 0;
  let weight () = Random.float 100. in
  let build_adj i =
    let rec aux j =
      if j = n then
        []
      else if (i <> j) && Random.int (n - 1) < avg_outdegree then
        (j, weight ()) :: aux (j + 1)
      else aux (j + 1) in
    aux 0 in
  Array.init n build_adj

let g1 = random_graph 20 2

let g2 = random_graph 1000 10


let dijkstra g i = assert false

let test_dijkstra () =
  let array_sum = Array.fold_left (+.) 0. in
  let t =
    [|infinity; 81.7504732238099763; 0.; 143.075476397307966; infinity;
      287.497339971473707; infinity; infinity; infinity; 217.478348335512379;
      infinity; infinity; infinity; 256.889526772049521; 87.4875853046628578;
      infinity; infinity; 146.271960347437471; 81.8422628400316654;
      infinity|] in
  assert (dijkstra g1 2 = t);
  assert (array_sum (dijkstra g2 10) = 73114.7316078792);
  print_endline "OK"


let dijkstra_tree g i = assert false


let test_dijkstra_tree () =
  let _, tree = dijkstra_tree g1 2 in
  let t =
    [|None; Some 2; Some 2; Some 14; None; Some 13; None; None; None; Some 17;
    None; None; None; Some 9; Some 2; None; None; Some 18; Some 2; None|] in
  assert (t = tree);
  print_endline "OK"

let reconstruct_path p goal = assert false

let test_reconstruct_path () =
  let _, t = dijkstra_tree g2 10 in
  let path = [10; 524; 54; 625; 343; 118; 771; 12] in
  assert (path = reconstruct_path t 12);
  print_endline "OK"

type commune =
  {id : int;
   insee : string;
   nom : string;
   pop : int;
   dep : string}


let lire_communes nom_fichier = assert false

let lire_graphe nb_communes fichier_adjacence = assert false

let tab_communes = [||]

let g_adj = [||]

let affiche chemin =
  let affiche_commune i =
    let c = tab_communes.(i) in
    Printf.printf "%s (%s) : %d\n" c.nom c.dep c.pop in
  List.iter affiche_commune chemin


let saute_canton init = assert false
